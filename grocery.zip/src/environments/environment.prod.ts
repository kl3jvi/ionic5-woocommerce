export const environment = {
  production: true,
  firebaseConfig: {
    apiKey: "AIzaSyB4OfgJ-n-Wts7IfVunk8RXOJsWilblkyw",
    authDomain: "notifications-a2s48b.firebaseapp.com",
    databaseURL: "https://notifications-a2s48b.firebaseio.com",
    projectId: "notifications-a2s48b",
    storageBucket: "notifications-a2s48b.appspot.com",
    messagingSenderId: "1081317927975",
    appId: "1:1081317927975:web:9610493fdf0d1c775f7202"
  }
};
