import { Component } from '@angular/core';
import { HttpClient } from '@angular/common/http'
import { WooCommerceService } from 'src/app/services/woocommerce.service';
import { Router } from '@angular/router';
@Component({
  selector: 'app-tab1',
  templateUrl: 'tab1.page.html',
  styleUrls: ['tab1.page.scss']
})
export class Tab1Page {
  public getProducts;
  constructor(
    public woocommerceService: WooCommerceService,
    private http: HttpClient,
    private route: Router) {
    this.getProducts = []
    console.log('Woocomerce')
    const products = this.woocommerceService.getProducts();
    console.log('getProduct');
    this.http.get(products).subscribe((res: any) => {
      console.log('data', res)
      this.getProducts = res;
    })
  }

}
